CREATE TABLE Personnes(
   numero_personne INTEGER,
   nom_personne VARCHAR(100),
   prenom_personne VARCHAR(100),
   salaire_personne FLOAT
);

CREATE TABLE Clients(
   numero_client INTEGER PRIMARY KEY,
   nom_client INTEGER,
   adresse_client VARCHAR(100)
);

CREATE TABLE Camions(
   immat_camion VARCHAR(100) PRIMARY KEY,
   marque_camion VARCHAR(100),
   dateAchat_camion DATE
);

CREATE TABLE Secretaires(
   numero_personne INTEGER,
   numero_client INTEGER
);

CREATE TABLE Chauffeurs_base(
   numero_personne INTEGER PRIMARY KEY
);

CREATE TABLE Distances (
   villeDepart_distance VARCHAR2(100) NOT NULL,
   villeArrivee_distance VARCHAR2(100) NOT NULL,
   nombreKilometres_distance INTEGER
);

CREATE TABLE Contrats(
   numero_contrat INTEGER PRIMARY KEY,
   dateDepart_contrat DATE,
   dateArrivee_contrat DATE,
   villeDepart_distance VARCHAR(100),
   villeArrivee_distance  VARCHAR(100),
   numero_client INTEGER,
   immat_camion VARCHAR(100),
   numero_personne INTEGER
);

------------------------------------------------------------
------- INSERTS --------------------------------------------
------------------------------------------------------------

INSERT INTO Distances (villeDepart_distance, villeArrivee_distance, nombreKilometres_distance) VALUES 
   ('Lyon', 'Marseille', 314),
   ('Lyon', 'Paris', 466),
   ('Lyon', 'Grenoble', 112), 
   ('Marseille', 'Grenoble', 306),
   ('Marseille', 'Lyon', 314),
   ('Marseille', 'Paris', 774),
   ('Grenoble', 'Marseille', 306),
   ('Grenoble', 'Paris', 574),
   ('Grenoble', 'Lyon', 112),
   ('Paris', 'Marseille', 774),
   ('Paris', 'Lyon', 466),
   ('Paris', 'Grenoble', 574);

INSERT INTO Personnes (numero_personne, nom_personne, prenom_personne, salaire_personne) VALUES 
   (1, 'Peyrin', 'Jean-Pierre', 68),
   (2, 'Fauvet', 'Marie-Christine', 140),
   (3, 'Bouchenak', 'Sara', 140),
   (4, 'Tonton', 'Michael', 160),
   (5, 'L''enchanteur', 'Merlin', 160),
   (6, 'Adrian', 'Laporte', 666);

INSERT INTO Clients (numero_client, nom_client, adresse_client) VALUES 
   (1001, 'Mickey Mouse', 'Echirolles'),
   (1002, 'Tintin', 'Bruxelles'),
   (1003, 'Rantanplan', 'Washington'),
   (1004, 'Mafalda', 'Gap');

INSERT INTO Camions (immat_camion, marque_camion, dateAchat_camion) VALUES 
   ('1675 WZ 38', 'renault', '2004-05-01'),
   ('1 A 38', 'renault', '2005-01-01'),
   ('13 CHX 38', 'renault', '2016-07-14'),
   ('18 CHX 38', 'renault', '2017-07-14'),
   ('20 CHX 38', 'renault', '2017-07-14');


INSERT INTO Secretaires (numero_personne, numero_client) VALUES 
   (2, 1001),
   (2, 1002),
   (4, 1003);

INSERT INTO Chauffeurs_base (numero_personne) VALUES 
	(1),
	(3),
	(5);
	
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) VALUES 
   ('2022-01-01', '2022-02-21', 'Lyon', 'Marseille', 1001, '13 CHX 38', 3),
   ('2020-12-05', '2021-01-01', 'Marseille', 'Paris', 1001, '1 A 38', 3),
   ('2022-08-05', '2022-08-17', 'Lyon', 'Paris', 1002, '1675 WZ 38', 5);