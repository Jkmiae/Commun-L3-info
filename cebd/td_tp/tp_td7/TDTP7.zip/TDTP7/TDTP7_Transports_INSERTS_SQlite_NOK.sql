--NOK (on n'accepte pas des personnes avec meme noP)
INSERT INTO Personnes (numero_personne, nom_personne, prenom_personne, salaire_personne) VALUES (1, 'Pierre', 'Dupont', 111);
--NOK (on n'accepte pas des personnes sans nom_personne et prenom_personne)
INSERT INTO Personnes (numero_personne, nom_personne, prenom_personne, salaire_personne) VALUES (7, 'Pedro', NULL, 40);
INSERT INTO Personnes (numero_personne, nom_personne, prenom_personne, salaire_personne) VALUES (8, NULL, 'Martinez', 40);
--NOK (on n'accepte pas des secretaires qui ne sont pas dans la relation Personnes) 
INSERT INTO Secretaires (numero_personne, numero_client) VALUES (8, 1004);
--NOK (on n'accepte pas des secretaires lies a un client qui n'est pas repertorie dans la relation Clients) 
INSERT INTO Secretaires (numero_personne, numero_client) VALUES (2, 1006);
--NOK (on n'accepte pas des clients qui sont sous la responsabilite de differentes secretaires) 
INSERT INTO Secretaires (numero_personne, numero_client) VALUES (2, 1001);
--NOK (on n'accepte pas des clients sans secretaire) 
INSERT INTO Secretaires (numero_personne, numero_client) VALUES (NULL, 1007);

--NOK (on n'accepte pas deux fois la distance entre les mêmes villes) 
INSERT INTO Distances (villeDepart_distance, villeArrivee_distance, nombreKilometres_distance) VALUES ('Paris', 'Grenoble', 0);


--NOK (on n'accepte pas des secretaires comme chauffeurs dans un contrat)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES  ('2022-08-04', '2022-08-05', 'Lyon', 'Paris', 1002, '1675 WZ 38', 2);
--NOK (on n'accepte que des camions repertories dans la relation Camions)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES  ('2022-08-04', '2022-08-05', 'Lyon', 'Paris', 1002, '1675 WZ 39', 2);
 
 
--NOK (on n'accepte pas des contrats sans chauffeur)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES  ('2022-08-05', '2022-08-17', 'Lyon', 'Paris', 1002, '13 CHX 38', NULL);
--NOK (on n'accepte pas des contrats sans camion)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES  ('2022-08-04', '2022-08-17', 'Lyon', 'Paris', 1002, NULL, 1);

--NOK (on n'accepte pas des departs et arrivees sur la meme ville)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne)
   VALUES  ('2022-08-05', '2022-08-07', 'Lyon', 'Lyon', 1002, '1675 WZ 38', 1);
--NOK (on n'accepte pas une date d'arrivee plus recente qu'une date de depart sur un contrat)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES  ('2022-09-18', '2022-09-15', 'Lyon', 'Paris', 1002, '1675 WZ 38', 5);
   
--------------------------------------------------------------------------------------------
--Contraintes avancées qu'on ne peut pas contrôler avec des contraintes d'intégrité
--Besoin des TRIGGERS. Attention : Syntaxe SQLite différente qu'ORACLE
--Exemples ici : https://youtu.be/i3xwZw5VRMs
--Explications ici : https://youtu.be/s9iRD-zrxS0
--------------------------------------------------------------------------------------------  
-- [NOK] (on n'accepte pas dateDepart_contrat < dateAchat pour un Camion)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES ('2000-09-16', '2000-09-17', 'Lyon', 'Grenoble', 1002, '18 CHX 38', 1);   
-- [NOK] (on n'accepte pas l'insertion du chauffeur numero_personne=4 si existe deja une secretaire avec numero_personne=4)
INSERT INTO Chauffeurs_base (numero_personne) VALUES (4);
-- [NOK] (on n'accepte pas l'insertion d'une secretaire numero_personne=3 si existe deja un chauffeur avec numero_personne=3)
INSERT INTO Secretaires (numero_personne, numero_client) VALUES (3, 1004);
-- [NOK] (on n'accepte pas un chevauchement des dates pour un chauffeur)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne)
   VALUES ('2022-02-01',  '2022-02-28', 'Grenoble', 'Marseille', 1002, '1675 WZ 38', 3);
-- [NOK] (on n'accepte pas un chevauchement des dates pour un camion)
INSERT INTO Contrats (dateDepart_contrat, dateArrivee_contrat, villeDepart_distance, villeArrivee_distance, numero_client, immat_camion, numero_personne) 
   VALUES ('2022-01-30', '2022-01-5', 'Lyon', 'Marseille', 1001, '13 CHX 38', 1);